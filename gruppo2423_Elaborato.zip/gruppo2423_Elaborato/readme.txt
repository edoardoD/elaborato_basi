visionare l'applicativo al seguente link 
http://dodoesercizzi.altervista.org/app/index.php