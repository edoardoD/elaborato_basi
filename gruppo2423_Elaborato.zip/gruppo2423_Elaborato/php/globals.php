<?php
    $host= "localhost";
    $user="root";
    $password="";
    $dbName="my_dodoesercizzi";
?>